-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 26, 2023 at 05:04 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `asclepiusnew`
--

-- --------------------------------------------------------

--
-- Table structure for table `diagnosis`
--

CREATE TABLE `diagnosis` (
  `PID` int(32) DEFAULT NULL,
  `diagnosis` varchar(100) DEFAULT NULL,
  `doctor` varchar(64) NOT NULL,
  `diagdate` varchar(64) DEFAULT NULL,
  `diagtype` varchar(32) DEFAULT NULL,
  `prescription` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `PID` int(32) NOT NULL,
  `name` varchar(64) NOT NULL,
  `gender` varchar(32) NOT NULL,
  `age` int(32) NOT NULL,
  `bldgrp` varchar(32) DEFAULT NULL,
  `contact` varchar(32) NOT NULL,
  `address` varchar(100) NOT NULL,
  `regdate` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`PID`, `name`, `gender`, `age`, `bldgrp`, `contact`, `address`, `regdate`) VALUES
(1, 'Ankush', 'Male', 20, 'B-', '8551093490', 'something', '10/10/2002'),
(2, 'someone', 'Male', 35, 'AB+', '9876543210', 'somewhere', '27/03/2023'),
(3, 'john', 'Female', 100, 'AB-', '9876543210', 'vandrapada', '07/04/2023');

-- --------------------------------------------------------

--
-- Table structure for table `people`
--

CREATE TABLE `people` (
  `name` varchar(32) NOT NULL,
  `joining` varchar(16) DEFAULT NULL,
  `email` varchar(32) NOT NULL,
  `contact` int(11) NOT NULL,
  `role` varchar(16) NOT NULL,
  `starttime` varchar(16) DEFAULT NULL,
  `endtime` varchar(16) DEFAULT NULL,
  `password` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `people`
--

INSERT INTO `people` (`name`, `joining`, `email`, `contact`, `role`, `starttime`, `endtime`, `password`) VALUES
('Ankush Singh', '04/02/2023', 'ankush@gmail.com', 1234567890, 'DOCTOR', '12:00am', '1:00am', 'ankush123'),
('Ankush', '05/02/2023', 'ankush@hotmail.com', 1234567890, 'STAFF', '12:00am', '1:00am', 'ankush123'),
('AnkushMod', '10/10/2002', 'ankush@gmail.com', 1234567890, 'MOD', 'NS', 'NS', 'ankush123'),
('Demo User', '', 'demouser@gmail.com', 1234567890, 'DOCTOR', '1:00am', '2:00am', 'demouser'),
('Demo User', '', 'demouser@gmail.com', 12345, 'STAFF', 'NS', 'NS', 'demouser');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `diagnosis`
--
ALTER TABLE `diagnosis`
  ADD KEY `fk_pid` (`PID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`PID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `PID` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `diagnosis`
--
ALTER TABLE `diagnosis`
  ADD CONSTRAINT `fk_pid` FOREIGN KEY (`PID`) REFERENCES `patient` (`PID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
